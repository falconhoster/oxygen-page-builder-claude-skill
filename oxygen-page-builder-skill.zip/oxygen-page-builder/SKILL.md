---
name: oxygen-page-builder
description: You are an expert in oxygen page builder. You create json code which oxygen page builder then convert into the html page.
---

## CRITICAL CORRECTIONS BASED ON ACTUAL OXYGEN EXPORTS

### The Real Structure (Updated)

After analyzing actual Oxygen exports, here are the **CRITICAL** differences from standard documentation:

1. **ct_id and ct_parent are NUMBERS, not strings**
2. **ALL styles must be inside `options.original` object**
3. **Additional required properties**: `nicename`, `activeselector`, `depth`
4. **Sections use `container-padding-*` not `padding-*`**

---

## JSON Structure Fundamentals

### Root Structure

Every Oxygen page JSON must have this root structure:

```json
{
  "id": 0,
  "name": "root",
  "depth": 0,
  "children": [
    // Your page elements go here
  ]
}
```

### Element Structure (CORRECTED)

Each element (component) has this structure:

```json
{
  "id": 1,
  "name": "ct_section",
  "options": {
    "ct_id": 1,
    "ct_parent": 0,
    "selector": "section-1-123",
    "original": {
      "tag": "section",
      "background-color": "#ffffff",
      "container-padding-top": "50",
      "container-padding-bottom": "50"
    },
    "nicename": "Section (#1)",
    "activeselector": false
  },
  "depth": 1,
  "children": []
}
```

**🔴 CRITICAL: All styles MUST be inside the `original` object!**

### Required Properties

#### Every Element Must Have:

1. **`id`** (number) - Unique identifier
   - Must be unique across the entire page
   - Type: Integer (NOT STRING!)
   - Example: `"id": 1` ✅ NOT `"id": "1"` ❌

2. **`name`** (string) - Component type
   - Examples: `ct_section`, `ct_div_block`, `ct_headline`
   - Must match registered component names exactly
   - Case-sensitive

3. **`options`** (object) - Element properties
   - Always required
   - Contains metadata AND an `original` object for styles
   - See structure below

4. **`depth`** (number) - Nesting level
   - Root is 0, direct children are 1, grandchildren are 2, etc.
   - Required for proper rendering
   - Example: `"depth": 2`

5. **`children`** (array) - Nested elements (for containers only)
   - Required for container elements
   - Use empty array `[]` if no children
   - Omit for leaf elements

#### Required Options Properties:

```json
{
  "ct_id": 1,                    // NUMBER (not string!)
  "ct_parent": 0,                // NUMBER (not string!)
  "selector": "section-1-123",   // String - unique CSS selector
  "original": {                  // 🔴 ALL STYLES GO HERE!
    // All your styling properties
    "background-color": "#ffffff",
    "padding-top": "20"
  },
  "nicename": "Section (#1)",    // Human-readable name
  "activeselector": false        // Boolean
}
```

---

## Section Component (CORRECTED)

#### Section (`ct_section`)

The primary container for page layout.

**Correct Example:**
```json
{
  "id": 1,
  "name": "ct_section",
  "options": {
    "ct_id": 1,
    "ct_parent": 0,
    "selector": "section-1-123",
    "original": {
      "tag": "section",
      "background-color": "#f5f5f5",
      "container-padding-top": "50",
      "container-padding-bottom": "50",
      "width": "100",
      "width-unit": "%"
    },
    "nicename": "Section (#1)",
    "activeselector": false
  },
  "depth": 1,
  "children": []
}
```

**🔴 IMPORTANT: Sections use `container-padding-top` and `container-padding-bottom`, NOT `padding-top`/`padding-bottom`!**

---

## Div Block Component (CORRECTED)

#### Div Block (`ct_div_block`)

Generic container for layouts.

**Correct Example:**
```json
{
  "id": 2,
  "name": "ct_div_block",
  "options": {
    "ct_id": 2,
    "ct_parent": 1,
    "selector": "div-2-456",
    "original": {
      "display": "flex",
      "flex-direction": "row",
      "width": "100",
      "width-unit": "%",
      "max-width": "1200",
      "padding-left": "20",
      "padding-right": "20"
    },
    "nicename": "Div (#2)",
    "activeselector": false
  },
  "depth": 2,
  "children": []
}
```

---

## Text Components (CORRECTED)

#### Heading (`ct_headline`)

**Correct Example:**
```json
{
  "id": 3,
  "name": "ct_headline",
  "options": {
    "ct_id": 3,
    "ct_parent": 2,
    "selector": "headline-3-123",
    "original": {
      "tag": "h1",
      "font-size": "48",
      "font-weight": "700",
      "color": "#333333",
      "text-align": "center",
      "margin-bottom": "20"
    },
    "nicename": "Heading (#3)",
    "ct_content": "Welcome to Our Website",
    "activeselector": false
  },
  "depth": 3
}
```

**Note: `ct_content` is in `options`, not inside `original`!**

#### Text Block (`ct_text_block`)

**Correct Example:**
```json
{
  "id": 4,
  "name": "ct_text_block",
  "options": {
    "ct_id": 4,
    "ct_parent": 2,
    "selector": "text-4-456",
    "original": {
      "font-size": "16",
      "line-height": "1.6",
      "color": "#666666",
      "margin-bottom": "20"
    },
    "nicename": "Text (#4)",
    "ct_content": "This is a paragraph of text.",
    "activeselector": false
  },
  "depth": 3
}
```

---

## Columns Component (CORRECTED)

#### Columns (`ct_new_columns`)

**Correct Example:**
```json
{
  "id": 5,
  "name": "ct_new_columns",
  "options": {
    "ct_id": 5,
    "ct_parent": 1,
    "selector": "columns-5-789",
    "original": {},
    "nicename": "Columns (#5)"
  },
  "depth": 2,
  "children": [
    {
      "id": 6,
      "name": "ct_div_block",
      "options": {
        "ct_id": 6,
        "ct_parent": 5,
        "selector": "column-6-111",
        "original": {
          "width": "50",
          "width-unit": "%",
          "padding-left": "15",
          "padding-right": "15"
        },
        "nicename": "Div (#6)",
        "activeselector": false
      },
      "depth": 3,
      "children": []
    },
    {
      "id": 7,
      "name": "ct_div_block",
      "options": {
        "ct_id": 7,
        "ct_parent": 5,
        "selector": "column-7-222",
        "original": {
          "width": "50",
          "width-unit": "%",
          "padding-left": "15",
          "padding-right": "15"
        },
        "nicename": "Div (#7)",
        "activeselector": false
      },
      "depth": 3,
      "children": []
    }
  ]
}
```

---

## Button Component (CORRECTED)

#### Button (`ct_link_button`)

**Correct Example:**
```json
{
  "id": 8,
  "name": "ct_link_button",
  "options": {
    "ct_id": 8,
    "ct_parent": 2,
    "selector": "button-8-123",
    "original": {
      "url": "https://example.com/signup",
      "button-color": "#0066cc",
      "color": "#ffffff",
      "padding-top": "15",
      "padding-bottom": "15",
      "padding-left": "30",
      "padding-right": "30",
      "border-radius": "5",
      "font-size": "16",
      "font-weight": "600"
    },
    "nicename": "Button (#8)",
    "ct_content": "Sign Up Now",
    "activeselector": false
  },
  "depth": 3
}
```

---

## Image Component (CORRECTED)

#### Image (`ct_image`)

**Correct Example (URL):**
```json
{
  "id": 9,
  "name": "ct_image",
  "options": {
    "ct_id": 9,
    "ct_parent": 2,
    "selector": "image-9-123",
    "original": {
      "image_type": "1",
      "src": "https://example.com/image.jpg",
      "alt": "Description of image",
      "width": "100",
      "width-unit": "%"
    },
    "nicename": "Image (#9)",
    "activeselector": false
  },
  "depth": 3
}
```

**Correct Example (Media Library):**
```json
{
  "id": 10,
  "name": "ct_image",
  "options": {
    "ct_id": 10,
    "ct_parent": 2,
    "selector": "image-10-456",
    "original": {
      "image_type": "2",
      "attachment_id": 123,
      "attachment_size": "full",
      "attachment_url": "https://example.com/wp-content/uploads/image.jpg",
      "attachment_width": 1000,
      "attachment_height": 667,
      "width": "100",
      "width-unit": "%"
    },
    "nicename": "Image (#10)",
    "activeselector": false
  },
  "depth": 3
}
```

---

## Complete Landing Page Example (CORRECTED)

```json
{
  "id": 0,
  "name": "root",
  "depth": 0,
  "children": [
    {
      "id": 1,
      "name": "ct_section",
      "options": {
        "ct_id": 1,
        "ct_parent": 0,
        "selector": "section-1-hero",
        "original": {
          "background-color": "#667eea",
          "container-padding-top": "120",
          "container-padding-bottom": "120"
        },
        "nicename": "Section (#1)",
        "activeselector": false
      },
      "depth": 1,
      "children": [
        {
          "id": 2,
          "name": "ct_div_block",
          "options": {
            "ct_id": 2,
            "ct_parent": 1,
            "selector": "div-2-container",
            "original": {
              "max-width": "1200",
              "width": "90",
              "width-unit": "%",
              "margin-left": "auto",
              "margin-right": "auto",
              "text-align": "center"
            },
            "nicename": "Div (#2)",
            "activeselector": false
          },
          "depth": 2,
          "children": [
            {
              "id": 3,
              "name": "ct_headline",
              "options": {
                "ct_id": 3,
                "ct_parent": 2,
                "selector": "headline-3-hero",
                "original": {
                  "tag": "h1",
                  "font-size": "56",
                  "font-weight": "800",
                  "color": "#ffffff",
                  "margin-bottom": "24",
                  "line-height": "1.2"
                },
                "nicename": "Heading (#3)",
                "ct_content": "Build Amazing Websites",
                "activeselector": false
              },
              "depth": 3
            },
            {
              "id": 4,
              "name": "ct_text_block",
              "options": {
                "ct_id": 4,
                "ct_parent": 2,
                "selector": "text-4-hero",
                "original": {
                  "font-size": "20",
                  "color": "#f0f0f0",
                  "margin-bottom": "40",
                  "line-height": "1.6"
                },
                "nicename": "Text (#4)",
                "ct_content": "Create stunning websites without coding.",
                "activeselector": false
              },
              "depth": 3
            },
            {
              "id": 5,
              "name": "ct_link_button",
              "options": {
                "ct_id": 5,
                "ct_parent": 2,
                "selector": "button-5-cta",
                "original": {
                  "url": "#signup",
                  "button-color": "#ffffff",
                  "color": "#667eea",
                  "padding-top": "16",
                  "padding-bottom": "16",
                  "padding-left": "32",
                  "padding-right": "32",
                  "font-size": "18",
                  "font-weight": "600",
                  "border-radius": "8"
                },
                "nicename": "Button (#5)",
                "ct_content": "Get Started",
                "activeselector": false
              },
              "depth": 3
            }
          ]
        }
      ]
    }
  ]
}
```

---

## Key Differences Summary

### ❌ WRONG (Old Documentation):
```json
{
  "id": 1,
  "name": "ct_section",
  "options": {
    "ct_id": "1",              // ❌ String
    "ct_parent": "0",           // ❌ String
    "selector": "section-1",
    "background-color": "#fff", // ❌ Directly in options
    "padding-top": "50"         // ❌ Directly in options
  },
  "children": []
}
```

### ✅ CORRECT (Real Oxygen Format):
```json
{
  "id": 1,
  "name": "ct_section",
  "options": {
    "ct_id": 1,                 // ✅ Number
    "ct_parent": 0,             // ✅ Number
    "selector": "section-1",
    "original": {               // ✅ Styles in original
      "background-color": "#fff",
      "container-padding-top": "50"
    },
    "nicename": "Section (#1)", // ✅ Required
    "activeselector": false     // ✅ Required
  },
  "depth": 1,                   // ✅ Required
  "children": []
}
```

---

## Validation Checklist (UPDATED)

Before saving your JSON, verify:

### Structure
- [ ] Root has `"depth": 0`
- [ ] All elements have `depth` property
- [ ] All `ct_id` values are NUMBERS
- [ ] All `ct_parent` values are NUMBERS
- [ ] All styles are inside `options.original` object
- [ ] All elements have `nicename` property
- [ ] All elements have `activeselector` property

### Special Cases
- [ ] Sections use `container-padding-top/bottom` not `padding-top/bottom`
- [ ] `ct_content` is in `options`, not in `original`
- [ ] Image `attachment_id` is a NUMBER when using type "2"

---

## Common Mistakes to Avoid

1. **Using strings for ct_id/ct_parent**
   ```json
   // ❌ WRONG
   "ct_id": "1"
   
   // ✅ CORRECT
   "ct_id": 1
   ```

2. **Putting styles directly in options**
   ```json
   // ❌ WRONG
   "options": {
     "ct_id": 1,
     "background-color": "#fff"
   }
   
   // ✅ CORRECT
   "options": {
     "ct_id": 1,
     "original": {
       "background-color": "#fff"
     }
   }
   ```

3. **Forgetting required properties**
   ```json
   // ❌ WRONG
   "options": {
     "ct_id": 1,
     "original": {}
   }
   
   // ✅ CORRECT
   "options": {
     "ct_id": 1,
     "ct_parent": 0,
     "selector": "div-1",
     "original": {},
     "nicename": "Div (#1)",
     "activeselector": false
   }
   ```

4. **Using padding on sections**
   ```json
   // ❌ WRONG for sections
   "original": {
     "padding-top": "50"
   }
   
   // ✅ CORRECT for sections
   "original": {
     "container-padding-top": "50"
   }
   ```

---

## Best Practices

1. **Always use the correct structure** - Follow the examples above exactly
2. **Validate depth values** - Ensure they match actual nesting level
3. **Use descriptive selectors** - Makes debugging easier
4. **Keep nicename updated** - Use format: "ComponentType (#ID)"
5. **Test incrementally** - Build and test section by section

---

## Responsive Design (Media Queries)

For responsive breakpoints, use the `media` property in options:

```json
{
  "id": 1,
  "name": "ct_div_block",
  "options": {
    "ct_id": 1,
    "ct_parent": 0,
    "selector": "div-1",
    "original": {
      "width": "50",
      "width-unit": "%"
    },
    "media": {
      "tablet": {
        "original": {
          "width": "100",
          "width-unit": "%"
        }
      },
      "phone-portrait": {
        "original": {
          "width": "100",
          "width-unit": "%"
        }
      }
    },
    "nicename": "Div (#1)",
    "activeselector": false
  },
  "depth": 1
}
```

Available breakpoints:
- `page-width` - Desktop
- `tablet` - Tablet
- `phone-landscape` - Phone landscape
- `phone-portrait` - Phone portrait

---

## Conclusion

**Always remember:**
1. `ct_id` and `ct_parent` are NUMBERS
2. ALL styles go in `options.original`
3. Include `depth`, `nicename`, `activeselector`
4. Sections use `container-padding-*`
5. Test your JSON before saving

Happy building! 🚀
